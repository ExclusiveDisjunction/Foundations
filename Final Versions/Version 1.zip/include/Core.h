#pragma once

#include "CharDelem.h"
#include "Color.h"
#include "Container.h"
#include "DateTime.h"
#include "Mapping.h"
#include "Str.h"
#include "Types\BasicObject.h"

/*
* This header provides basic code functionality, specifically lists and strings.
*/